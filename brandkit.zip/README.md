
  # brandkit

  This is a code bundle for brandkit. The original project is available at https://www.figma.com/design/udoHz4c19TrvJx5zPuvWrR/brandkit.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  